3D Folding Panel
=========

A secondary content panel that folds flat, powered by CSS Transformations and jQuery.

[Article on CodyHouse](http://codyhouse.co/gem/3d-folding-panel/)

[Demo](http://codyhouse.co/demo/3d-folding-effect/index.html)
 
[Terms](http://codyhouse.co/terms/)
